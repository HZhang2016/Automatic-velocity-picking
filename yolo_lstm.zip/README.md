# 速度谱能量团检测（YOLO）+ 多次波去除（LSTM）

基于合成地震数据的速度谱自动解释流程：

1. **MATLAB 正演**：随机生成层状介质模型 → 合成地震记录 → 速度分析得到速度谱，输出训练样本（`train_inputdata/` 速度谱、`train_outputdata/` (速度, T0) 标签）；
2. **YOLO 检测**：在速度谱上检测所有能量团（矩形框，单类）；
3. **LSTM 去多次波**：把检测到的能量团按 T0 排序成序列，逐点判别一次波 / 多次波，剔除多次波；
4. **(v, T0) 提取**：保留下来的矩形框按标定位置（框内 40% 宽度处）换算为（速度, T0）对，与真实标签对比。

## 目录结构

```
yolo_lstm/
├── README.md                  # 本文档
├── run_all.bat                # 一键运行脚本（Windows）
├── configs/
│   └── settings.yaml          # 参数说明（修改参数请改 src/common.py）
├── src/                       # 代码
│   ├── common.py              #   共享路径、常量、LSTM 模型定义（单一事实来源）
│   ├── make_dataset.py        #   数据集构建：连通域提取能量团 → 矩形框 → YOLO/LSTM 格式
│   ├── train_yolo.py          #   YOLOv8n 训练
│   ├── train_lstm.py          #   LSTM 训练
│   ├── test_all.py            #   端到端测试（检测指标 + LSTM 正确率 + 一次波恢复率）
│   ├── predict_and_plot.py    #   推理 + (v,T0) 提取 + viridis 对比绘图
│   └── calibrate_offset.py    #   标定框内速度取值位置 f
├── dataset/                   # 数据（由 make_dataset.py 生成）
│   ├── dataset.yaml           #   YOLO 数据集配置（必须为 ASCII 相对路径，勿改）
│   ├── images/{train,val,test}/*.png
│   ├── labels/{train,val,test}/*.txt
│   └── lstm_data.npz
├── models/                    # 训练好的权重
│   ├── yolo_best.pt
│   └── lstm_best.pt
├── predictions/               # 预测结果
│   ├── predicted_VT_f040.csv  #   预测的 (速度, T0) 对（推荐使用）
│   ├── figs_f040/             #   100 张预测 vs 真实对比图（viridis）
│   ├── figs/                  #   中心点版本对比图（基线）
│   └── *.png                  #   标注抽查图、测试可视化图
└── yolo_runs-3/               # YOLO 训练过程输出（训练曲线、混淆矩阵等）
```

MATLAB 侧文件在本项目上一级目录 `ai_code/`：`Start_createdata.m`（主脚本）、
`CreateModel.m`、`Syn_Seismogram.m`、`Vel_Analysis.m`、`createVT.m`、
`PreprocessData.m`、`wigb.m`（自绘波形图，替代 CREWES 工具箱）。

## 环境依赖

- MATLAB（R2022b 已验证）
- Python 3.12，依赖：`torch`、`ultralytics`、`numpy`、`pillow`、`matplotlib`

```bash
pip install torch ultralytics numpy pillow matplotlib
```

## 使用步骤

> ⚠️ 所有 Python 脚本都必须从**项目根目录 `yolo_lstm/`** 运行
> （即 `python src/xxx.py`），不要 `cd src` 后运行——
> ultralytics 按当前工作目录解析 `dataset.yaml` 中的相对路径。

### 0. 生成训练样本（MATLAB）

在 `ai_code/` 下运行 `Start_createdata.m`（`train_num` 控制样本数），
生成 `train_inputdata/*.csv`（速度谱，每行一个值，共 201×251=50451 行）
和 `train_outputdata/*.csv`（(速度,T0) 交替 + 第 19 个数=界面数、第 20 个=多次波个数）。

### 1. 一键运行（推荐）

双击 `run_all.bat`，依次执行：构建数据集 → 训练 YOLO（CPU 约 45 分钟）
→ 训练 LSTM（约 1 分钟）→ 端到端测试 → 推理绘图。

### 2. 分步运行

```bash
python src/make_dataset.py        # 构建数据集（80/10/10 划分）
python src/train_yolo.py          # 训练 YOLO，权重自动复制到 models/yolo_best.pt
python src/train_lstm.py          # 训练 LSTM，保存 models/lstm_best.pt
python src/test_all.py            # 打印检测指标、LSTM 正确率、端到端恢复率
python src/predict_and_plot.py    # 推理全部样本，输出 CSV + 对比图
python src/predict_and_plot.py --fraction 0.5   # 可选：改用框中心换算（基线）
python src/calibrate_offset.py    # 可选：重新标定最优 fraction
```

## 输出说明

- `predictions/predicted_VT_f040.csv`：预测的 (速度, T0) 对，
  三列 `样本号, 速度(m/s), T0(s)`；
- `predictions/figs_f040/sample_XXX.png`：viridis 色阶速度谱 +
  红圈（真实标签）+ 青叉（预测点）；
- `test_all.py` 输出三类指标（见下）。

## 当前结果（100 个样本，80 训练 / 10 验证 / 10 测试）

| 环节 | 指标 | 结果 |
|---|---|---|
| YOLO 检测（val 集） | mAP@0.5 / mAP@0.5:0.95 | 0.995 / 0.791 |
| | 精确率 / 召回率 | 0.994 / 0.991 |
| LSTM 判别（test 集） | 一次波/多次波判别正确率 | 100% |
| 端到端（test 集） | 一次波恢复率 / 精确率 | 98.5% / 100% |
| (v,T0) 提取（全部样本，f=0.40） | 匹配率 | 93.3%（657/704） |
| | 速度误差（均值 / MAE） | +7.8 / 33.4 m/s |
| | T0 误差（MAE） | 6.8 ms |

**关于 f=0.40**：真实标签（平均速度, T0）位于能量团左边缘附近，
而 YOLO 框带外扩边距、能量团向右拖尾，因此框内约 40% 宽度处与标签
对齐最好（由 `calibrate_offset.py` 在 0~0.5 间扫描标定）。
框中心（f=0.5）会导致速度系统性偏大 +57 m/s，左边缘（f=0）偏小 -128 m/s。

## 常见问题

1. **Dataset images not found / 路径乱码**：ultralytics 在中文 Windows 下
   按 GBK 读取 yaml，且相对路径基于**当前工作目录**解析。
   请保持 `dataset/dataset.yaml` 为 ASCII 相对路径（`path: ./dataset`），
   并从 `yolo_lstm/` 根目录运行脚本。
2. **yolov8n.pt 预训练权重下载失败**（GitHub 无法访问）：
   `train_yolo.py` 使用 `yolov8n.yaml` 从头训练，无需下载任何权重。
   若网络可用，改回 `YOLO('yolov8n.pt')` 可加快收敛。
3. **扩大样本量**：修改 MATLAB `Start_createdata.m` 的 `train_num`，
   重新生成后修改 `src/common.py` 的 `N_SAMPLES` 和 `SPLIT`，
   再从第 1 步重新运行。
