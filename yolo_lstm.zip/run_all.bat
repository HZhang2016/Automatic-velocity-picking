@echo off
chcp 65001 >nul
REM ============================================================
REM  速度谱能量团检测 + 多次波去除 —— 一键运行脚本
REM  前置条件：
REM   1. 已安装 Python 依赖：torch ultralytics numpy pillow matplotlib
REM   2. 已用 MATLAB 运行 Start_createdata.m 生成
REM      train_inputdata/ 和 train_outputdata/（在本目录的上一级）
REM ============================================================
cd /d %~dp0

echo [1/5] 构建数据集 ...
python src\make_dataset.py || goto :error

echo [2/5] 训练 YOLO（CPU 约 45 分钟）...
python src\train_yolo.py || goto :error

echo [3/5] 训练 LSTM ...
python src\train_lstm.py || goto :error

echo [4/5] 端到端测试 ...
python src\test_all.py || goto :error

echo [5/5] 推理并绘制对比图（f=0.40 标定版）...
python src\predict_and_plot.py --fraction 0.40 || goto :error

echo.
echo 全部完成！结果见 predictions\ 目录。
goto :eof

:error
echo.
echo 运行失败，请检查上方报错信息。
exit /b 1
