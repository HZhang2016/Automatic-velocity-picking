# -*- coding: utf-8 -*-
"""
train_yolo.py — 训练 YOLOv8n 检测速度谱能量团（单类 cluster）
运行：python src/train_yolo.py
输出：yolo_runs/weights/best.pt，并自动复制到 models/yolo_best.pt

说明：网络受限无法下载预训练权重时，使用 yolov8n.yaml 从头训练；
     合成数据结构简单，从头训练即可收敛。
"""
import os
import shutil

from ultralytics import YOLO

from common import DS_DIR, MODELS_DIR, PROJECT_DIR, YOLO_WEIGHTS


def main():
    os.makedirs(MODELS_DIR, exist_ok=True)
    model = YOLO('yolov8n.yaml')        # 从头训练（无需下载预训练权重）
    model.train(
        data=os.path.join(DS_DIR, 'dataset.yaml'),
        epochs=100,
        imgsz=640,
        batch=16,
        workers=0,
        device='cpu',
        project=PROJECT_DIR,
        name='yolo_runs',
    )
    # 训练完成后把最优权重复制到 models/（run 目录可能带 -2/-3 后缀）
    runs_dir = os.path.join(PROJECT_DIR, 'yolo_runs')
    if not os.path.exists(os.path.join(runs_dir, 'weights', 'best.pt')):
        for i in range(2, 10):
            cand = os.path.join(PROJECT_DIR, f'yolo_runs-{i}', 'weights', 'best.pt')
            if os.path.exists(cand):
                runs_dir = os.path.join(PROJECT_DIR, f'yolo_runs-{i}')
                break
    best = os.path.join(runs_dir, 'weights', 'best.pt')
    shutil.copy(best, YOLO_WEIGHTS)
    print(f'YOLO 训练完成，权重已复制到 {YOLO_WEIGHTS}')


if __name__ == '__main__':
    main()
