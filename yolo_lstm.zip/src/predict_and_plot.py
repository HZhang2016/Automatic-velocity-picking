# -*- coding: utf-8 -*-
"""
predict_and_plot.py — 推理 + 对比绘图
对全部样本执行 YOLO 检测 + LSTM 去除多次波，
将保留矩形框换算为 (速度, t0) 对，与真实标签对比并绘图（viridis 色阶）。

运行：python src/predict_and_plot.py [--fraction 0.40] [--conf 0.25]
  --fraction  框内速度取值位置：0=左边缘, 0.5=中心, 默认 0.40（经标定最优）
输出：predictions/predicted_VT_fXXX.csv
      predictions/figs_fXXX/sample_XXX.png
"""
import argparse
import os

import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ultralytics import YOLO

from common import (DS_DIR, H, W, IN_DIR, OUT_DIR, LSTM_WEIGHTS, MAX_LEN,
                    PRED_DIR, DT, DV, V_FRACTION, YOLO_WEIGHTS,
                    ClusterLSTM, split_of)

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei']
plt.rcParams['axes.unicode_minus'] = False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--fraction', type=float, default=V_FRACTION,
                    help='框内速度取值位置: 0=左边缘, 0.5=中心, 默认 0.40')
    ap.add_argument('--conf', type=float, default=0.25, help='YOLO 置信度阈值')
    args = ap.parse_args()
    frac = args.fraction
    tag = f'f{int(round(frac * 100)):03d}'

    fig_dir = os.path.join(PRED_DIR, f'figs_{tag}')
    os.makedirs(fig_dir, exist_ok=True)

    yolo = YOLO(YOLO_WEIGHTS)
    lstm = ClusterLSTM()
    lstm.load_state_dict(torch.load(LSTM_WEIGHTS))
    lstm.eval()

    records = []
    dv_all, dt_all = [], []
    n_match, n_true_total = 0, 0

    for sid in range(1, 101):
        fin = os.path.join(IN_DIR, f'{sid}.csv')
        fout = os.path.join(OUT_DIR, f'{sid}.csv')
        if not (os.path.exists(fin) and os.path.exists(fout)):
            continue
        spectrum = np.loadtxt(fin, delimiter=',').reshape(H, W, order='F')
        raw = np.loadtxt(fout, delimiter=',')
        n_ref = int(raw[18])
        truth = raw[:2 * n_ref].reshape(n_ref, 2)

        img_path = os.path.join(DS_DIR, 'images', split_of(sid), f'{sid}.png')
        res = yolo.predict(img_path, device='cpu', verbose=False,
                           conf=args.conf)[0]

        pred_pairs = []
        if len(res.boxes) > 0:
            boxes = res.boxes.xyxy.cpu().numpy()
            confs = res.boxes.conf.cpu().numpy()
            items = []
            for (x0, y0, x1, y1), cf in zip(boxes, confs):
                sx, sy = W / res.orig_shape[1], H / res.orig_shape[0]
                x0, x1, y0, y1 = x0 * sx, x1 * sx, y0 * sy, y1 * sy
                items.append([((x0 + x1) / 2) * DV / 5000,
                              ((y0 + y1) / 2) * DT / 2.0,
                              (x1 - x0) / W, (y1 - y0) / H, float(cf),
                              x0, x1, (y0 + y1) / 2 * DT])
            items.sort(key=lambda z: z[1])
            T = min(len(items), MAX_LEN)
            x = np.zeros((1, MAX_LEN, 5), np.float32)
            x[0, :T] = np.array([it[:5] for it in items[:T]])
            with torch.no_grad():
                keep = (torch.sigmoid(
                    lstm(torch.tensor(x), torch.tensor([T])))[0, :T] > 0.5).numpy()
            for it, k in zip(items[:T], keep):
                if k:  # 一次波：框内 fraction 位置 -> (速度, t0)
                    pred_pairs.append(
                        [(it[5] + frac * (it[6] - it[5])) * DV, it[7]])

        pred_pairs = np.array(pred_pairs).reshape(-1, 2)

        # 与真实标签匹配（最近点，容差 dv=150 m/s, dt=0.05 s），统计误差
        used = set()
        for pv, pt in pred_pairs:
            best, best_j = None, -1
            for j, (tv, tt) in enumerate(truth):
                if j in used:
                    continue
                if abs(pv - tv) <= 150 and abs(pt - tt) <= 0.05:
                    d = abs(pt - tt)
                    if best is None or d < best:
                        best, best_j = d, j
            if best_j >= 0:
                used.add(best_j)
                dv_all.append(pv - truth[best_j, 0])
                dt_all.append(pt - truth[best_j, 1])
                n_match += 1
        n_true_total += n_ref

        for pv, pt in pred_pairs:
            records.append([sid, pv, pt])

        # ---------- 绘图 ----------
        fig, ax = plt.subplots(figsize=(9, 7))
        im = ax.imshow(spectrum, aspect='auto', origin='upper',
                       extent=[0, 5000, 2.0, 0], cmap='viridis')
        fig.colorbar(im, ax=ax, label='叠加能量（白化后）')
        ax.scatter(truth[:, 0], truth[:, 1], s=130, facecolors='none',
                   edgecolors='red', linewidths=1.8, label='真实 (v, t0)')
        if len(pred_pairs) > 0:
            ax.scatter(pred_pairs[:, 0], pred_pairs[:, 1], s=70, marker='x',
                       c='cyan', linewidths=2,
                       label=f'预测 (v, t0)-f={frac:.2f}')
        ax.set_xlabel('速度 (m/s)')
        ax.set_ylabel('T0 时间 (s)')
        ax.set_title(f'样本 {sid}：预测(f={frac:.2f}) vs 真实 (v, t0) 对  '
                     f'(真实 {n_ref} 个 / 预测 {len(pred_pairs)} 个)')
        ax.legend(loc='upper right')
        fig.tight_layout()
        fig.savefig(os.path.join(fig_dir, f'sample_{sid:03d}.png'), dpi=120)
        plt.close(fig)

    out_csv = os.path.join(PRED_DIR, f'predicted_VT_{tag}.csv')
    np.savetxt(out_csv, np.array(records), delimiter=',', fmt='%.2f',
               header=f'sample_id,v_pred_{tag}(m/s),t0_pred(s)', comments='')

    print(f'预测 (v,t0) 对已保存: {out_csv}（共 {len(records)} 对）')
    print(f'图已保存到: {fig_dir}')
    print(f'匹配上的 (v,t0) 对: {n_match}/{n_true_total}')
    if dv_all:
        print(f'速度误差: 均值 {np.mean(dv_all):+.1f} m/s, '
              f'平均绝对误差 {np.mean(np.abs(dv_all)):.1f} m/s')
        print(f'T0 误差:  均值 {np.mean(dt_all) * 1000:+.2f} ms, '
              f'平均绝对误差 {np.mean(np.abs(dt_all)) * 1000:.2f} ms')


if __name__ == '__main__':
    main()
