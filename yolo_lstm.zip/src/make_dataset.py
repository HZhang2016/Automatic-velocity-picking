# -*- coding: utf-8 -*-
"""
make_dataset.py — 构建数据集
从 MATLAB 生成的速度谱 CSV 构建：
1. YOLO 检测数据集：速度谱 PNG 图 + 能量团矩形框标签（单类 cluster）
2. LSTM 序列数据：每个样本的能量团序列特征 + 一次波/多次波标签

运行：python src/make_dataset.py
输出：dataset/images/{train,val,test}/*.png
      dataset/labels/{train,val,test}/*.txt
      dataset/lstm_data.npz
      dataset/dataset.yaml
"""
import os
from collections import deque

import numpy as np
from PIL import Image

from common import (AI_CODE_DIR, DS_DIR, H, W, DT, DV, N_SAMPLES, SPLIT,
                    IN_DIR, OUT_DIR)

MARGIN = 2  # 矩形框外扩像素


def find_components(mask):
    """8-连通域搜索，返回每个连通域的像素坐标列表"""
    seen = np.zeros_like(mask, dtype=bool)
    comps = []
    rows, cols = np.nonzero(mask)
    for r0, c0 in zip(rows, cols):
        if seen[r0, c0]:
            continue
        q = deque([(r0, c0)])
        seen[r0, c0] = True
        pix = []
        while q:
            r, c = q.popleft()
            pix.append((r, c))
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < mask.shape[0] and 0 <= nc < mask.shape[1] \
                            and mask[nr, nc] and not seen[nr, nc]:
                        seen[nr, nc] = True
                        q.append((nr, nc))
        if len(pix) >= 2:          # 滤掉孤立噪点
            comps.append(pix)
    return comps


def comp_bbox(pix, margin=MARGIN):
    rs = [p[0] for p in pix]
    cs = [p[1] for p in pix]
    r0, r1 = max(0, min(rs) - margin), min(H - 1, max(rs) + margin)
    c0, c1 = max(0, min(cs) - margin), min(W - 1, max(cs) + margin)
    return r0, r1, c0, c1


def point_in(r, c, bbox, tol=3):
    r0, r1, c0, c1 = bbox
    return (r0 - tol) <= r <= (r1 + tol) and (c0 - tol) <= c <= (c1 + tol)


def main():
    for split in SPLIT:
        os.makedirs(os.path.join(DS_DIR, 'images', split), exist_ok=True)
        os.makedirs(os.path.join(DS_DIR, 'labels', split), exist_ok=True)

    lstm_samples = []
    stats = {s: 0 for s in SPLIT}
    skipped = []

    for sid in range(1, N_SAMPLES + 1):
        fin = os.path.join(IN_DIR, f'{sid}.csv')
        fout = os.path.join(OUT_DIR, f'{sid}.csv')
        if not (os.path.exists(fin) and os.path.exists(fout)):
            skipped.append(sid)
            continue

        spectrum = np.loadtxt(fin, delimiter=',').reshape(H, W, order='F')
        raw = np.loadtxt(fout, delimiter=',')
        n_ref = int(raw[18])
        n_mul = int(raw[19])
        primaries = raw[:2 * n_ref].reshape(n_ref, 2)      # (v, t0)
        # 多次波位置：速度恒为第一层速度，t0 为 T0(1) 的整数倍
        v1, t01 = primaries[0]
        multiples = np.array([[v1, t01 * (k + 1)] for k in range(1, n_mul + 1)])
        multiples = multiples[multiples[:, 1] <= 2.0]      # 超出时窗的丢弃

        comps = find_components(spectrum > 0)

        boxes, feats, cls = [], [], []
        for pix in comps:
            r0, r1, c0, c1 = comp_bbox(pix)
            energy = float(
                spectrum[[p[0] for p in pix], [p[1] for p in pix]].mean())
            w_px, h_px = c1 - c0 + 1, r1 - r0 + 1
            label = -1
            for v, t in primaries:
                if point_in(t / DT, v / DV, (r0, r1, c0, c1)):
                    label = 1
                    break
            if label == -1:
                for v, t in multiples:
                    if point_in(t / DT, v / DV, (r0, r1, c0, c1)):
                        label = 0
                        break
            if label == -1:
                continue  # 噪声团，不标
            cx, cy = (c0 + c1) / 2 / W, (r0 + r1) / 2 / H
            boxes.append([0, cx, cy, w_px / W, h_px / H])  # YOLO 单类
            feats.append([((c0 + c1) / 2) * DV / 5000,     # v 中心(归一化)
                          ((r0 + r1) / 2) * DT / 2.0,      # t0 中心
                          w_px / W, h_px / H, energy / 1e6])
            cls.append(label)

        if not boxes:
            skipped.append(sid)
            continue

        order = np.argsort([f[1] for f in feats])          # 按 t0 排序
        feats = np.array(feats)[order]
        cls = np.array(cls)[order]

        split = next(s for s, rg in SPLIT.items() if sid in rg)
        stats[split] += 1

        img = (spectrum / max(spectrum.max(), 1) * 255).astype(np.uint8)
        Image.fromarray(img).save(
            os.path.join(DS_DIR, 'images', split, f'{sid}.png'))
        with open(os.path.join(DS_DIR, 'labels', split, f'{sid}.txt'), 'w') as f:
            for b in np.array(boxes)[order]:
                f.write(' '.join(f'{x:.6f}' for x in b) + '\n')
        lstm_samples.append((feats.astype(np.float32), cls.astype(np.int64), sid))

    np.savez(os.path.join(DS_DIR, 'lstm_data.npz'),
             samples=np.array(lstm_samples, dtype=object), allow_pickle=True)

    # 注意：path 必须为 ASCII 相对路径（ultralytics 在中文 Windows 下
    # 按 GBK 读取 yaml，中文绝对路径会乱码）；且 ultralytics 将 path
    # 解析到 yaml 所在目录的上一级，故写 ./dataset
    with open(os.path.join(DS_DIR, 'dataset.yaml'), 'w') as f:
        f.write("path: ./dataset\n"
                "train: images/train\nval: images/val\ntest: images/test\n"
                "names:\n  0: cluster\n")

    print(f'完成: train={stats["train"]} val={stats["val"]} test={stats["test"]}')
    print(f'LSTM 序列样本数: {len(lstm_samples)}')
    if skipped:
        print('跳过的样本:', skipped)


if __name__ == '__main__':
    main()
