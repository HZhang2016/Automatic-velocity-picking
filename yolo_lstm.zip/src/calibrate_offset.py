# -*- coding: utf-8 -*-
"""
calibrate_offset.py — 标定框内速度取值位置 f（0=左边缘, 0.5=中心）
扫描多个 f 值，输出匹配数与误差，用于选择最优 V_FRACTION。
运行：python src/calibrate_offset.py
"""
import os

import numpy as np
import torch
from ultralytics import YOLO

from common import (DS_DIR, H, W, IN_DIR, OUT_DIR, LSTM_WEIGHTS, MAX_LEN,
                    DT, DV, YOLO_WEIGHTS, ClusterLSTM, split_of)

FRACS = [0.0, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5]


def main():
    yolo = YOLO(YOLO_WEIGHTS)
    lstm = ClusterLSTM()
    lstm.load_state_dict(torch.load(LSTM_WEIGHTS))
    lstm.eval()

    stats = {f: {'n': 0, 'dv': [], 'dt': []} for f in FRACS}
    n_true_total = 0

    for sid in range(1, 101):
        fin = os.path.join(IN_DIR, f'{sid}.csv')
        fout = os.path.join(OUT_DIR, f'{sid}.csv')
        if not (os.path.exists(fin) and os.path.exists(fout)):
            continue
        raw = np.loadtxt(fout, delimiter=',')
        n_ref = int(raw[18])
        truth = raw[:2 * n_ref].reshape(n_ref, 2)
        n_true_total += n_ref

        img_path = os.path.join(DS_DIR, 'images', split_of(sid), f'{sid}.png')
        res = yolo.predict(img_path, device='cpu', verbose=False, conf=0.25)[0]
        if len(res.boxes) == 0:
            continue
        boxes = res.boxes.xyxy.cpu().numpy()
        confs = res.boxes.conf.cpu().numpy()
        items = []
        for (x0, y0, x1, y1), cf in zip(boxes, confs):
            sx, sy = W / res.orig_shape[1], H / res.orig_shape[0]
            x0, x1, y0, y1 = x0 * sx, x1 * sx, y0 * sy, y1 * sy
            items.append([((x0 + x1) / 2) * DV / 5000,
                          ((y0 + y1) / 2) * DT / 2.0,
                          (x1 - x0) / W, (y1 - y0) / H, float(cf),
                          x0, x1, y0, y1])
        items.sort(key=lambda z: z[1])
        T = min(len(items), MAX_LEN)
        x = np.zeros((1, MAX_LEN, 5), np.float32)
        x[0, :T] = np.array([it[:5] for it in items[:T]])
        with torch.no_grad():
            keep = (torch.sigmoid(
                lstm(torch.tensor(x), torch.tensor([T])))[0, :T] > 0.5).numpy()

        for f in FRACS:
            used = set()
            for it, k in zip(items[:T], keep):
                if not k:
                    continue
                x0, x1, y0, y1 = it[5], it[6], it[7], it[8]
                pv = (x0 + f * (x1 - x0)) * DV
                pt = (y0 + y1) / 2 * DT
                best, best_j = None, -1
                for j, (tv, tt) in enumerate(truth):
                    if j in used:
                        continue
                    if abs(pv - tv) <= 150 and abs(pt - tt) <= 0.05:
                        d = abs(pt - tt)
                        if best is None or d < best:
                            best, best_j = d, j
                if best_j >= 0:
                    used.add(best_j)
                    stats[f]['n'] += 1
                    stats[f]['dv'].append(pv - truth[best_j, 0])
                    stats[f]['dt'].append(pt - truth[best_j, 1])

    print(f'{"位置f":>6} {"匹配数":>10} {"速度均值":>10} {"速度MAE":>10} '
          f'{"T0 MAE(ms)":>10}')
    for f in FRACS:
        s = stats[f]
        if s['n']:
            print(f'{f:6.2f} {s["n"]:6d}/{n_true_total} '
                  f'{np.mean(s["dv"]):+10.1f} {np.mean(np.abs(s["dv"])):10.1f} '
                  f'{np.mean(np.abs(s["dt"])) * 1000:10.2f}')


if __name__ == '__main__':
    main()
