# -*- coding: utf-8 -*-
"""common.py — 共享路径、常量和 LSTM 模型定义"""
import os
import torch
import torch.nn as nn

# ---------------- 路径 ----------------
SRC_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(SRC_DIR)                 # yolo_lstm/
AI_CODE_DIR = os.path.dirname(PROJECT_DIR)             # ai_code/（MATLAB 数据所在目录）

IN_DIR = os.path.join(AI_CODE_DIR, 'train_inputdata')  # MATLAB 速度谱输入 CSV
OUT_DIR = os.path.join(AI_CODE_DIR, 'train_outputdata')  # MATLAB 标签 CSV
DS_DIR = os.path.join(PROJECT_DIR, 'dataset')          # YOLO/LSTM 数据集
MODELS_DIR = os.path.join(PROJECT_DIR, 'models')       # 训练好的权重
PRED_DIR = os.path.join(PROJECT_DIR, 'predictions')    # 预测结果与对比图

YOLO_WEIGHTS = os.path.join(MODELS_DIR, 'yolo_best.pt')
LSTM_WEIGHTS = os.path.join(MODELS_DIR, 'lstm_best.pt')

# ---------------- 数据常量 ----------------
H, W = 201, 251        # 速度谱尺寸：t0 点数 x 速度点数
DT = 0.01              # t0 采样间隔 (s)，范围 0~2.0 s
DV = 20.0              # 速度采样间隔 (m/s)，范围 0~5000 m/s
N_SAMPLES = 100        # 样本总数
MAX_LEN = 32           # LSTM 序列最大长度
V_FRACTION = 0.40      # 框内速度取值位置（0=左边缘, 0.5=中心），经 calibrate_offset.py 标定

# 数据集划分：train=1~80, val=81~90, test=91~100
SPLIT = {'train': range(1, 81), 'val': range(81, 91), 'test': range(91, 101)}


def split_of(sid):
    for s, rg in SPLIT.items():
        if sid in rg:
            return s
    raise ValueError(sid)


# ---------------- LSTM 模型 ----------------
class ClusterLSTM(nn.Module):
    """逐点判别能量团为一次波(1)还是多次波(0)的双层 LSTM"""

    def __init__(self, feat_dim=5, hidden=64):
        super().__init__()
        self.lstm = nn.LSTM(feat_dim, hidden, num_layers=2,
                            batch_first=True, dropout=0.1)
        self.fc = nn.Linear(hidden, 1)

    def forward(self, x, lengths):
        packed = nn.utils.rnn.pack_padded_sequence(
            x, lengths.cpu(), batch_first=True, enforce_sorted=False)
        out, _ = self.lstm(packed)
        out, _ = nn.utils.rnn.pad_packed_sequence(
            out, batch_first=True, total_length=x.size(1))
        return self.fc(out).squeeze(-1)
