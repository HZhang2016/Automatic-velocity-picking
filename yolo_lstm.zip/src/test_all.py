# -*- coding: utf-8 -*-
"""
test_all.py — 端到端测试：YOLO 检测能量团 -> LSTM 去除多次波 -> 与真实标签比对
运行：python src/test_all.py
输出：1. YOLO 检测指标（val 集 mAP50 / 精确率 / 召回率）
     2. LSTM 判别正确率（test 集）
     3. 端到端一次波恢复率与精确率
"""
import os

import numpy as np
import torch
from ultralytics import YOLO

from common import (DS_DIR, LSTM_WEIGHTS, MAX_LEN, OUT_DIR, DT, DV,
                    YOLO_WEIGHTS, ClusterLSTM)


def main():
    print('=' * 50)
    print('1) YOLO 检测指标（val 集）')
    print('=' * 50)
    yolo = YOLO(YOLO_WEIGHTS)
    metrics = yolo.val(data=os.path.join(DS_DIR, 'dataset.yaml'), split='val',
                       device='cpu', workers=0, verbose=False)
    print(f'  mAP@0.5      = {metrics.box.map50:.4f}')
    print(f'  mAP@0.5:0.95 = {metrics.box.map:.4f}')
    print(f'  精确率 P     = {metrics.box.mp:.4f}')
    print(f'  召回率 R     = {metrics.box.mr:.4f}')

    print('=' * 50)
    print('2) 端到端测试（test 集：YOLO 检测 + LSTM 去除多次波）')
    print('=' * 50)
    lstm = ClusterLSTM()
    lstm.load_state_dict(torch.load(LSTM_WEIGHTS))
    lstm.eval()

    tot_prim, hit_prim, tot_pred_prim = 0, 0, 0
    lstm_tot, lstm_hit = 0, 0

    for sid in range(91, 101):
        img_path = os.path.join(DS_DIR, 'images', 'test', f'{sid}.png')
        if not os.path.exists(img_path):
            continue
        res = yolo.predict(img_path, device='cpu', verbose=False, conf=0.25)[0]
        if len(res.boxes) == 0:
            continue
        boxes = res.boxes.xyxy.cpu().numpy()
        confs = res.boxes.conf.cpu().numpy()

        # 构造 LSTM 输入序列（按 t0 排序）；items 保留框像素坐标用于匹配
        items = []
        for (x0, y0, x1, y1), cf in zip(boxes, confs):
            sx, sy = 251 / res.orig_shape[1], 201 / res.orig_shape[0]
            x0, x1, y0, y1 = x0 * sx, x1 * sx, y0 * sy, y1 * sy
            items.append([((x0 + x1) / 2) * 20.0 / 5000,
                          ((y0 + y1) / 2) * DT / 2.0,
                          (x1 - x0) / 251, (y1 - y0) / 201, float(cf),
                          x0, x1, y0, y1])
        items.sort(key=lambda z: z[1])
        T = min(len(items), MAX_LEN)
        x = np.zeros((1, MAX_LEN, 5), np.float32)
        x[0, :T] = np.array([it[:5] for it in items[:T]])
        with torch.no_grad():
            prob = torch.sigmoid(lstm(torch.tensor(x), torch.tensor([T])))[0, :T]
        keep = prob.numpy() > 0.5                 # True=一次波

        # 与真实一次波标签匹配：真实 (v,t0) 位于能量团左边缘附近，
        # 判据为标签点落在预测框内（外扩 ±5px≈100m/s, ±3px≈0.03s）
        raw = np.loadtxt(os.path.join(OUT_DIR, f'{sid}.csv'), delimiter=',')
        n_ref = int(raw[18])
        truth = raw[:2 * n_ref].reshape(n_ref, 2)
        used = set()
        for it, k in zip(items[:T], keep):
            if not k:
                continue
            tot_pred_prim += 1
            x0, x1, y0, y1 = it[5], it[6], it[7], it[8]
            for j, (v, t) in enumerate(truth):
                pv, pt = v / 20.0, t / DT
                if j not in used and (x0 - 5) <= pv <= (x1 + 5) \
                        and (y0 - 3) <= pt <= (y1 + 3):
                    used.add(j)
                    hit_prim += 1
                    break
        tot_prim += n_ref

        # LSTM 在真实框上的判别正确率（单独统计）
        data = np.load(os.path.join(DS_DIR, 'lstm_data.npz'), allow_pickle=True)
        for feats, cls, s in data['samples']:
            if s == sid:
                Tt = min(len(feats), MAX_LEN)
                xt = np.zeros((1, MAX_LEN, 5), np.float32)
                xt[0, :Tt] = feats[:Tt]
                with torch.no_grad():
                    pt = torch.sigmoid(
                        lstm(torch.tensor(xt), torch.tensor([Tt])))[0, :Tt]
                pred = (pt.numpy() > 0.5).astype(int)
                lstm_hit += int((pred == cls[:Tt]).sum())
                lstm_tot += Tt
                break

    print(f'  LSTM 判别正确率（真实框输入）: {lstm_hit}/{lstm_tot} '
          f'= {lstm_hit / max(lstm_tot, 1):.4f}')
    print(f'  一次波恢复率（召回）: {hit_prim}/{tot_prim} '
          f'= {hit_prim / max(tot_prim, 1):.4f}')
    print(f'  预测为一次波的框数: {tot_pred_prim}，其中正确: {hit_prim}'
          f'，精确率 = {hit_prim / max(tot_pred_prim, 1):.4f}')


if __name__ == '__main__':
    main()
