# -*- coding: utf-8 -*-
"""
train_lstm.py — 训练 LSTM 判别能量团为一次波(1)还是多次波(0)，用于去除多次波
运行：python src/train_lstm.py
输出：models/lstm_best.pt
"""
import os

import numpy as np
import torch
import torch.nn as nn

from common import DS_DIR, LSTM_WEIGHTS, MAX_LEN, MODELS_DIR, ClusterLSTM

torch.manual_seed(0)


def load(split_ids):
    data = np.load(os.path.join(DS_DIR, 'lstm_data.npz'), allow_pickle=True)
    X, Y, M = [], [], []
    for feats, cls, sid in data['samples']:
        if sid not in split_ids:
            continue
        T = min(len(feats), MAX_LEN)
        x = np.zeros((MAX_LEN, 5), np.float32)
        y = np.zeros(MAX_LEN, np.float32)
        m = np.zeros(MAX_LEN, np.float32)
        x[:T] = feats[:T]
        y[:T] = cls[:T]
        m[:T] = 1
        X.append(x)
        Y.append(y)
        M.append(m)
    return (torch.tensor(np.array(X)), torch.tensor(np.array(Y)),
            torch.tensor(np.array(M)),
            torch.tensor([int(m.sum()) for m in M]))


def main():
    os.makedirs(MODELS_DIR, exist_ok=True)
    Xtr, Ytr, Mtr, Ltr = load(range(1, 81))
    Xte, Yte, Mte, Lte = load(range(91, 101))
    print(f'训练序列 {len(Xtr)} 条，测试序列 {len(Xte)} 条')

    model = ClusterLSTM()
    opt = torch.optim.Adam(model.parameters(), lr=1e-3)
    loss_fn = nn.BCEWithLogitsLoss(reduction='none')

    best_acc = 0.0
    for epoch in range(1, 201):
        model.train()
        opt.zero_grad()
        logits = model(Xtr, Ltr)
        loss = (loss_fn(logits, Ytr) * Mtr).sum() / Mtr.sum()
        loss.backward()
        opt.step()
        if epoch % 40 == 0:
            model.eval()
            with torch.no_grad():
                pred = (torch.sigmoid(model(Xte, Lte)) > 0.5).float()
                acc = ((pred == Yte).float() * Mte).sum() / Mte.sum()
            print(f'epoch {epoch:3d}  loss={loss.item():.4f}  '
                  f'test_acc={acc.item():.4f}')
            if acc.item() >= best_acc:
                best_acc = acc.item()
                torch.save(model.state_dict(), LSTM_WEIGHTS)

    print(f'LSTM 训练完成，权重保存在 {LSTM_WEIGHTS}（best acc={best_acc:.4f}）')


if __name__ == '__main__':
    main()
